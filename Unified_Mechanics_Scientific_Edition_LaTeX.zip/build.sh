#!/usr/bin/env bash
# Full build: xelatex, bibtex, xelatex twice, for every volume plus the series.
set -u
cd "$(dirname "$0")"
for v in volume-i volume-ii volume-iii volume-iv volume-v; do
  printf '%-14s ' "$v"
  rm -f "$v".{aux,toc,out,bbl,blg,log}
  xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
  bibtex "$v" >/dev/null 2>&1
  xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
  xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
  errs=$(grep -c "^! " "$v.log" 2>/dev/null || echo 0)
  undef=$(grep -c "undefined" "$v.log" 2>/dev/null || echo 0)
  pages=$(pdfinfo "$v.pdf" 2>/dev/null | sed -n 's/^Pages:\s*//p')
  echo "pages=${pages:-FAIL}  errors=$errs  undefined=$undef"
done
v=unified-mechanics-series
printf '%-14s ' "$v"
rm -f "$v".{aux,toc,out,bbl,blg,log}
xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
bibtex "$v" >/dev/null 2>&1
xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
xelatex -interaction=nonstopmode "$v.tex" >/dev/null 2>&1
echo "pages=$(pdfinfo "$v.pdf" | sed -n 's/^Pages:\s*//p')  errors=$(grep -c '^! ' "$v.log")"
