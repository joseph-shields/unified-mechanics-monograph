# Unified Mechanics — Living Scientific Edition

This package contains the complete five-volume LaTeX series and the omnibus edition dated 2 August 2026.

## Build

Compile from this directory with Tectonic 0.16.9 or later:

```text
tectonic volume-i.tex
tectonic volume-ii.tex
tectonic volume-iii.tex
tectonic volume-iv.tex
tectonic volume-v.tex
tectonic unified-mechanics-series.tex
```

Each top-level file is self-contained apart from the shared `umseries.sty`, `references.bib`, `volumes/`, and `generated/` files included in this package. The generated source crosswalk is already present; `generate_source_crosswalk.py` can regenerate it from `audit/coverage_ledger_mapped.csv`.

## Scientific status

This is a living scientific edition, not a frozen doctrine. Every statement is graded as an established result, internal result, conditional identification, conjecture, forecast, exposure, or open obligation. Earlier freeze manifests are retained solely as historical provenance or preregistration records; they do not prevent correction, supersession, or withdrawal.

## Audit state

- 491 unique text-bearing sources are represented in the complete crosswalk.
- 75 cited bibliography keys resolve to 77 supplied bibliography records.
- All six PDFs compile without unresolved citations, unresolved cross-references, errors, or overfull boxes.
- Every page was rendered and visually inspected; intentional blank recto pages preserve book structure.

