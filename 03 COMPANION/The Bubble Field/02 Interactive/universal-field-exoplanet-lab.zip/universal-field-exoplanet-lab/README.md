# Universal Field of Least Action — Exoplanet Ensemble Lab

Open `index.html` in a modern browser with internet access. The page first queries the current NASA Exoplanet Archive Planetary Systems table. If that is unavailable, it tries an older NASA-archive snapshot and finally a small embedded demonstration sample.

## What it calculates

For every catalogue orbit with period `P`, semi-major axis `a`, and host mass ratio:

- gravitational parameter: `mu = 4 pi^2 a^3 / P^2`
- mean orbital acceleration scale: `g_bar = 4 pi^2 a / P^2`
- free ensemble regression: `log(g_bar) = c + alpha log(M) + n log(a)`
- conditional `G`, after supplying an absolute solar-mass scale in kilograms
- a representative phase reconstruction of position `r`, velocity `v`, and field acceleration `g`
- angular momentum, radial/tangential velocity, energy, torque, curvature, and the `v-g` angle

## Critical limitation

Astronomical dynamics directly determine `GM`, not `G` and `M` separately. Catalogue stellar masses in solar units are model-dependent, and many published semi-major axes are calculated using Kepler's law. The displayed value of `G` is therefore a catalogue-consistency result conditional on the entered absolute mass scale, not an independent measurement.

A genuine derivation of `G` from the framework would require an absolute mass in kilograms obtained without using gravitational dynamics. The site makes that missing bridge explicit rather than hiding it.
