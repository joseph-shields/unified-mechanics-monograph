# Universal Field of Least Action — Solar System Map

Open `index.html` in a modern browser.

## What it is

A self-contained interactive Solar System map combining:

- approximate JPL Keplerian planetary positions (valid 1800–2050),
- NASA comparative planet masses and radii,
- Joseph Shields' Universal Field of Least Action / Shields field interpretation,
- explicit status labels separating standard physics, reinterpretation, and speculative diagnostics.

## Controls

- Date and animated time
- Logarithmic, linear, and inner-system projections
- Physical-mass or compressed multiscale closure weighting
- Scalar field, bubble closure, relational boundary, gradient, orbit, radiative path, and nested-closure layers
- Scattering-curvature slider to demonstrate a non-potentiated co-distinction field
- Click planets to inspect closure depth, boundary proximity, isoperimetric holonomy efficiency, directional distinction, and loop residue

## Important limit

The non-zero loop residue is a toy path-dependent connection used to demonstrate what cannot be represented by a scalar potential alone. It is not an observed Solar System anomaly or a validated new interaction.
