"""Finite certificate for the typed distinction--record calculus.

The general statements are elementary propositions proved in the companion
volume. This script exhausts the smallest nontrivial histories and every
renaming of a three-symbol event alphabet to certify that the results depend on
structure (order, equality, concatenation and prefix) rather than vocabulary.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "certificates"
OUT.mkdir(parents=True, exist_ok=True)

DOINGS = ("distinguish", "hold", "close", "answer", "change", "order", "record")
EDGES = tuple(zip(DOINGS, DOINGS[1:]))


def admissible_order(p):
    at = {x: i for i, x in enumerate(p)}
    return all(at[a] < at[b] for a, b in EDGES)


def histories(alphabet, max_len):
    yield ()
    for n in range(1, max_len + 1):
        yield from itertools.product(alphabet, repeat=n)


def prefix_order(a, b):
    return len(a) <= len(b) and b[: len(a)] == a


def rename(h, permutation):
    return tuple(permutation[x] for x in h)


def structural_signature(h):
    """Invariant under bijective renaming: length, equality pattern, prefixes."""
    first = {}
    pattern = []
    for x in h:
        if x not in first:
            first[x] = len(first)
        pattern.append(first[x])
    prefixes = tuple(h[:k] for k in range(len(h) + 1))
    return len(h), tuple(pattern), tuple(len(x) for x in prefixes)


def main():
    orders = [p for p in itertools.permutations(DOINGS) if admissible_order(p)]

    alphabet = (0, 1, 2)
    hs = list(histories(alphabet, 4))
    permutations = [dict(zip(alphabet, p)) for p in itertools.permutations(alphabet)]

    renaming_checks = 0
    prefix_checks = 0
    injective_checks = 0
    for perm in permutations:
        for h in hs:
            rh = rename(h, perm)
            assert structural_signature(h) == structural_signature(rh)
            assert len(h) == len(rh)
            renaming_checks += 1
        for a in hs:
            for b in hs:
                assert prefix_order(a, b) == prefix_order(rename(a, perm), rename(b, perm))
                prefix_checks += 1

    # With an injective event encoder, append-only records identify histories.
    encoded = {h: tuple((x + 1) * 17 for x in h) for h in hs}
    for a in hs:
        for b in hs:
            assert (encoded[a] == encoded[b]) == (a == b)
            injective_checks += 1

    # The two-channel update [resolved, held] -> [resolved+held, resolved].
    # Its projective fixed ratio is the positive root of lambda^2-lambda-1.
    phi = (1 + math.sqrt(5)) / 2
    residual = abs(phi * phi - phi - 1)

    script = Path(__file__).resolve()
    cert = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "status": "completed",
        "typed_objects": {
            "event_alphabet": "finite set Sigma",
            "history": "finite word Sigma*",
            "record": "append-only encoded word in R*",
            "state": "ordered pair (resolved, held), distinct from its record",
            "observable": "map constant on the declared quotient classes",
        },
        "unique_doing_order": {
            "dependencies": EDGES,
            "permutations_examined": math.factorial(len(DOINGS)),
            "admissible_count": len(orders),
            "admissible_order": orders[0],
        },
        "finite_semantic_invariance": {
            "alphabet_size": len(alphabet),
            "maximum_history_length": 4,
            "histories": len(hs),
            "bijective_renamings": len(permutations),
            "signature_checks": renaming_checks,
            "prefix_relation_checks": prefix_checks,
            "all_passed": True,
        },
        "record_injectivity": {
            "ordered_history_pairs_checked": injective_checks,
            "condition": "event encoder is injective",
            "all_passed": True,
        },
        "two_channel_update": {
            "matrix": [[1, 1], [1, 0]],
            "characteristic_polynomial": "lambda^2-lambda-1",
            "positive_projective_fixed_ratio": phi,
            "polynomial_residual": residual,
        },
        "scope": "Finite certificate accompanying general proofs; it is not used as a substitute for those proofs.",
        "sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
    }
    path = OUT / "step1_record_axioms_certificate.json"
    path.write_text(json.dumps(cert, indent=2), encoding="utf-8")
    print(json.dumps({"certificate": str(path), "orders": len(orders),
                      "renaming_checks": renaming_checks,
                      "prefix_checks": prefix_checks,
                      "injective_checks": injective_checks,
                      "phi_residual": residual}, indent=2))


if __name__ == "__main__":
    main()
