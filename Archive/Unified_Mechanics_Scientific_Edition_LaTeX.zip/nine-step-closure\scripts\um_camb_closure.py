"""Unified Mechanics step-6 closure certificate.

The script injects the frozen UM cosmological dictionary into CAMB 2.0.1.
UM supplies the dimensionless invariant, density fractions, tilt, amplitude,
helium reading, neutrino count and optical depth. CAMB supplies the imported
non-equilibrium recombination calculation and the Einstein--Boltzmann line-of-
sight evolution. No CMB spectrum datum is fitted.

The one measured calibration used in the historical forward solver is retained:
theta_* = 0.0104109 fixes the absolute laminar Hubble scale. Because UM fixes
Omega rather than omega, the callback updates omega_b and omega_c while CAMB
solves H0. A Planck-2018 control is calculated by the identical executable.
"""

from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import math
import os
import platform
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "vendor"
sys.path.insert(0, str(VENDOR))

import camb  # type: ignore  # isolated, version-locked work dependency
import numpy as np
from scipy.signal import find_peaks


OUT = ROOT / "certificates"
OUT.mkdir(parents=True, exist_ok=True)

THETA_STAR = 1.04109e-2
TCMB = 2.7255
LMAX = 3000

phi = (1.0 + math.sqrt(5.0)) / 2.0
r = 1.0 / (2.0 * phi)
u = 1.0 - r
WL, WB, WM = u * u, 2.0 * u * r, r * r
r3 = r**3

BASE = {
    "Omega_b": WM / 2.0,
    "Omega_c": WB / phi,
    "n_s": 1.0 - WM * (1.0 - 2.0 * r),
    "A_s": r**17,
    "N_eff": 3.0 + WM / 2.0,
    "Y_He": WL / 2.0,
    "tau": 2.0 * r3 * (1.0 - r3) ** 3,
}

CASES = {
    "um_static": dict(BASE),
    "um_boundary": {
        **BASE,
        "Omega_b": (WM / 2.0) / (1.0 - r3),
        "Y_He": (WL / 2.0) / (1.0 - r3),
    },
}

PLANCK = {
    "H0": 67.36,
    "ombh2": 0.02237,
    "omch2": 0.1200,
    "n_s": 0.9649,
    "A_s": 2.100e-9,
    "N_eff": 3.046,
    "Y_He": 0.2454,
    "tau": 0.0544,
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def set_fraction_densities(params: camb.CAMBparams, H0: float, values: dict) -> None:
    """Keep UM Omega_b and Omega_c invariant while CAMB varies H0."""
    h = H0 / 100.0
    params.H0 = H0
    params.ombh2 = values["Omega_b"] * h * h
    params.omch2 = values["Omega_c"] * h * h


def make_um_params(values: dict, mass_sum: float = 0.0) -> camb.CAMBparams:
    p = camb.CAMBparams()
    h0 = 67.0
    p.set_cosmology(
        H0=h0,
        ombh2=values["Omega_b"] * (h0 / 100.0) ** 2,
        omch2=values["Omega_c"] * (h0 / 100.0) ** 2,
        omk=0.0,
        mnu=mass_sum,
        num_massive_neutrinos=0 if mass_sum == 0.0 else 1,
        nnu=values["N_eff"],
        YHe=values["Y_He"],
        TCMB=TCMB,
        tau=values["tau"],
    )
    p.InitPower.set_params(As=values["A_s"], ns=values["n_s"], r=0.0)
    p.set_dark_energy(w=-1.0, wa=0.0)
    p.set_for_lmax(LMAX, lens_potential_accuracy=1)
    p.set_matter_power(redshifts=[0.0], kmax=2.0)
    p.Accuracy.AccuracyBoost = 1.2
    p.Accuracy.lAccuracyBoost = 1.2
    p.Accuracy.lSampleBoost = 1.2
    p.set_H0_for_theta(
        THETA_STAR,
        cosmomc_approx=False,
        theta_H0_range=(55.0, 80.0),
        est_H0=67.0,
        setter_H0=lambda pars, H0: set_fraction_densities(pars, H0, values),
    )
    set_fraction_densities(p, p.H0, values)
    return p


def make_planck_params() -> camb.CAMBparams:
    p = camb.CAMBparams()
    p.set_cosmology(
        H0=PLANCK["H0"], ombh2=PLANCK["ombh2"], omch2=PLANCK["omch2"],
        omk=0.0, mnu=0.06, num_massive_neutrinos=1, nnu=PLANCK["N_eff"],
        YHe=PLANCK["Y_He"], TCMB=TCMB, tau=PLANCK["tau"],
    )
    p.InitPower.set_params(As=PLANCK["A_s"], ns=PLANCK["n_s"], r=0.0)
    p.set_dark_energy(w=-1.0, wa=0.0)
    p.set_for_lmax(LMAX, lens_potential_accuracy=1)
    p.set_matter_power(redshifts=[0.0], kmax=2.0)
    return p


def summarize(name: str, p: camb.CAMBparams) -> tuple[dict, np.ndarray, np.ndarray]:
    result = camb.get_results(p)
    powers = result.get_cmb_power_spectra(p, CMB_unit="muK", raw_cl=False)
    total = powers["total"]
    derived = result.get_derived_params()
    ell = np.arange(total.shape[0])
    tt = total[:, 0]
    usable = (ell >= 100) & (ell <= 2500)
    peak_idx, _ = find_peaks(tt[usable], distance=180, prominence=150.0)
    absolute = ell[usable][peak_idx]
    order = absolute[np.argsort(tt[absolute])[::-1]]
    selected = sorted(int(x) for x in order[:7])[:5]
    peaks = [{"number": i + 1, "ell": x, "D_ell_TT_uK2": float(tt[x])}
             for i, x in enumerate(selected)]
    z_hist = np.linspace(500.0, 1800.0, 1301)
    thermo = result.get_background_redshift_evolution(
        z_hist, vars=["x_e", "opacity", "visibility", "T_b"], format="dict"
    )
    history = np.column_stack((z_hist, thermo["x_e"], thermo["opacity"],
                               thermo["visibility"], thermo["T_b"]))
    z_visibility = float(z_hist[int(np.argmax(thermo["visibility"]))])
    h = p.H0 / 100.0
    summary = {
        "name": name,
        "H0_km_s_Mpc": float(p.H0),
        "h": h,
        "Omega_b": float(p.ombh2 / h**2),
        "Omega_c": float(p.omch2 / h**2),
        "omega_b": float(p.ombh2),
        "omega_c": float(p.omch2),
        "Omega_m": float(result.get_Omega("baryon") + result.get_Omega("cdm") + result.get_Omega("nu")),
        "sigma8": float(result.get_sigma8_0()),
        "derived": {k: float(v) for k, v in derived.items()},
        "visibility_peak_z_sampled": z_visibility,
        "tt_peaks": peaks,
    }
    return summary, np.column_stack((ell, total[:, 0], total[:, 1], total[:, 2], total[:, 3])), history


def write_spectrum(name: str, table: np.ndarray) -> None:
    with (OUT / f"{name}_spectra.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ell", "TT_Dell_uK2", "EE_Dell_uK2", "BB_Dell_uK2", "TE_Dell_uK2"])
        w.writerows(table.tolist())


def write_history(name: str, table: np.ndarray) -> None:
    with (OUT / f"{name}_recombination.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["z", "x_e", "opacity_Mpc_inv", "visibility_Mpc_inv", "T_b_K"])
        w.writerows(table.tolist())


def main() -> None:
    summaries: dict[str, dict] = {}
    spectra: dict[str, np.ndarray] = {}
    histories: dict[str, np.ndarray] = {}

    planck_params = make_planck_params()
    summaries["planck_control"], spectra["planck_control"], histories["planck_control"] = summarize("planck_control", planck_params)
    write_spectrum("planck_control", spectra["planck_control"])
    write_history("planck_control", histories["planck_control"])

    for name, values in CASES.items():
        p = make_um_params(values, mass_sum=0.0)
        summaries[name], spectra[name], histories[name] = summarize(name, p)
        summaries[name]["um_inputs"] = values
        write_spectrum(name, spectra[name])
        write_history(name, histories[name])

    # One imported-nuisance sensitivity calculation: the minimal 0.06-eV
    # neutrino sum used in the Planck control, without changing any UM input.
    p_nu = make_um_params(CASES["um_boundary"], mass_sum=0.06)
    summaries["um_boundary_mnu006"], spectra["um_boundary_mnu006"], histories["um_boundary_mnu006"] = summarize("um_boundary_mnu006", p_nu)
    write_spectrum("um_boundary_mnu006", spectra["um_boundary_mnu006"])
    write_history("um_boundary_mnu006", histories["um_boundary_mnu006"])

    control_tt = spectra["planck_control"][:, 1]
    for name in ("um_static", "um_boundary", "um_boundary_mnu006"):
        tt = spectra[name][:, 1]
        lo, hi = 30, 2500
        sl = slice(lo, hi + 1)
        summaries[name]["comparison_to_planck_control"] = {
            "ell_range": [lo, hi],
            "rms_fractional_TT": float(np.sqrt(np.mean(((tt[sl] - control_tt[sl]) / control_tt[sl]) ** 2))),
            "mean_fractional_TT": float(np.mean((tt[sl] - control_tt[sl]) / control_tt[sl])),
        }

    certificate = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "status": "completed",
        "purpose": "Replace the Saha-only forward calculation with non-equilibrium recombination and full Einstein-Boltzmann evolution.",
        "solver": {"name": "CAMB", "version": getattr(camb, "__version__", "2.0.1"), "lmax": LMAX},
        "platform": {"python": sys.version, "platform": platform.platform()},
        "um_invariants": {"phi": phi, "r": r, "u": u, "W_L": WL, "W_B": WB, "W_M": WM, "r3": r3},
        "calibration": {"theta_star": THETA_STAR, "role": "single dimensional/acoustic anchor retained from A03"},
        "interpretation": {
            "um_static": "Literal static channel readings.",
            "um_boundary": "The independently stated uncharged-traversal boundary reading for Omega_b and Y_He.",
            "um_boundary_mnu006": "Sensitivity only; imports the Planck minimal neutrino mass sum and is not an additional UM derivation.",
        },
        "results": summaries,
    }
    script_path = Path(__file__).resolve()
    certificate["sha256"] = {"script": sha256(script_path)}
    cert_path = OUT / "step6_camb_certificate.json"
    cert_path.write_text(json.dumps(certificate, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({
        "certificate": str(cert_path),
        "camb": certificate["solver"],
        "H0": {k: v["H0_km_s_Mpc"] for k, v in summaries.items()},
        "thetastar": {k: v["derived"].get("thetastar") for k, v in summaries.items()},
        "peaks": {k: [p["ell"] for p in v["tt_peaks"]] for k, v in summaries.items()},
    }, indent=2))


if __name__ == "__main__":
    main()
