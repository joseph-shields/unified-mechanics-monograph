#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p build

for source in \
  current-scientific-position.tex \
  volume-i.tex \
  volume-ii.tex \
  volume-iii.tex \
  volume-iv.tex \
  volume-v.tex \
  unified-mechanics-series.tex
do
  tectonic --keep-logs --keep-intermediates -o build "$source"
done

mkdir -p derivation-programme/build
(
  cd derivation-programme
  tectonic --keep-logs --keep-intermediates -o build main.tex
)

mkdir -p nine-step-closure/latex/build
(
  cd nine-step-closure/latex
  tectonic --keep-logs --keep-intermediates -o build main.tex
)

printf '%s\n' 'Build completed. Run the release-level render and manifest checks before publication.'
