"""Freeze the four nine-step observable maps and preregistration fields."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "certificates"
OUT.mkdir(parents=True, exist_ok=True)

phi = (1 + math.sqrt(5)) / 2
r = 1 / (2 * phi)
u = 1 - r
WL, WB, WM = u*u, 2*u*r, r*r
r3 = r**3
q = 1-r3

H_lam = 67.7532219695113  # step-6 CAMB boundary certificate
n_pred = 3
H_mult = H_lam * q**(-n_pred)
H_linear = H_lam * (1+n_pred*r3)
H_symmetric = H_lam * (1+n_pred*r3/2)/(1-n_pred*r3/2)

lambda_planck = (4*math.pi/math.sqrt(3))*r**240
q_vac = r**241*(1-r3)**2

# Reproducibility branch of the Helical Relativity scale certificate.
hbar = 1.054571817e-34
c = 299792458.0
rho_lambda = 5.244697829924281e-10
a0 = (hbar*c/rho_lambda)**0.25
a_m = a0*WM**0.25

protocols = {
  "UM-HUBBLE-01": {
    "status": "frozen; prospective execution awaits a designated release",
    "primary_map": "n_hat = -ln(H_cond/H_lam)/ln(1-r^3)",
    "primary_prediction": {"n": n_pred, "H_laminar": H_lam, "H_condensed": H_mult},
    "sensitivity_only": {"linear": H_linear, "symmetric": H_symmetric},
    "rule": "The multiplicative map is primary because sequential retained fractions compose multiplicatively. Linear and symmetric maps are reported but may not replace it after unblinding.",
    "raw_inputs": "Published central values and full covariance for the predesignated early/light and late/condensed pipelines.",
    "decision_statistic": "distance of n_hat from the nearest integer, propagated from the published covariance",
    "revision_rule": "record the inferred n_hat and uncertainty whether or not it clusters near 3"
  },
  "UM-VACUUM-01": {
    "status": "frozen map; future precision set by geometric Lambda boundary",
    "maps": {
      "dimensionless_vacuum_readout": "lambda=(4*pi/sqrt(3))*r^240",
      "G_bridge": "G=8*pi*c^3*r^241*(1-r^3)^2/(hbar*Lambda)"
    },
    "values": {"lambda_planck_units": lambda_planck, "q_vacuum": q_vac},
    "raw_inputs": "A geometric determination of Lambda with its covariance; CODATA G is used only as the external comparator.",
    "decision_statistic": "standardised residual between G_bridge(Lambda) and CODATA G",
    "revision_rule": "retain both the measured residual and the status of the two-leg representation; do not absorb the residual into a fitted prefactor"
  },
  "UM-GRAVITY-01": {
    "status": "scale frozen; response kernel remains a named derivation requirement",
    "cell_scales": {"whole_cell_m": a0, "matter_channel_m": a_m, "matter_channel_micrometre": a_m*1e6},
    "observable": "residual torque versus separation after Newtonian, electrostatic, magnetic and Casimir backgrounds are fitted on control regions",
    "required_forward_map": "Delta tau(d)=A integral rho1(x)rho2(y) K(|x-y|/a_M) d3x d3y; a_M is fixed, while A and K must be derived before unblinding",
    "prohibition": "A Yukawa kernel may not be substituted for a granularity kernel unless the field derivation produces it.",
    "revision_rule": "publish the residual curve and covariance independently of whether structure is present near a_M"
  },
  "UM-RETENTION-01": {
    "status": "protocol skeleton; apparatus and retention observable must be selected before data",
    "prediction": "retention levels occur at declared integer powers r^n within the predeclared instrumental uncertainty model",
    "system_requirements": ["driven", "self-holding", "running", "observable state retention", "calibration independent of r"],
    "primary_statistic": "minimum distance in log space from measured retention to the predeclared integer lattice n*ln(r)",
    "blinding": "the analyst receives permuted condition labels and the integer assignment is frozen before labels are restored",
    "revision_rule": "enter the outcome in the living register regardless of proximity to a power of r"
  }
}

script=Path(__file__).resolve()
certificate={
 "generated_utc":dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
 "status":"completed",
 "invariants":{"phi":phi,"r":r,"u":u,"W_L":WL,"W_B":WB,"W_M":WM,"r3":r3},
 "protocols":protocols,
 "sha256":hashlib.sha256(script.read_bytes()).hexdigest()
}
path=OUT/'step7_8_observable_protocols.json'
path.write_text(json.dumps(certificate,indent=2),encoding='utf-8')
print(json.dumps({"certificate":str(path),"Hubble":[H_lam,H_mult,H_linear,H_symmetric],
                  "vacuum_readout":lambda_planck,"matter_cell_um":a_m*1e6},indent=2))
