# Scientific regrade of the inherited formal register

This is the editorial ruling for the living scientific edition. It preserves the content of A1--A6, D1--D18, and T1--T39 while separating exact mathematics from definitions, model assumptions, physical identifications, numerical certificates, and open conjectures. The inherited labels are provenance; the grades below govern the rewritten series.

## Commitments A1--A6

| ID | Living-edition grade | Ruling |
|---|---|---|
| A1 | Framework postulate | Permits a system to contain internal differences. This is a modelling convention, not an empirical axiom. |
| A2 | Ontological postulate | The assertion that distinction creates its own ``where'' is philosophical/constructive. No spacetime conclusion follows without an explicit mathematical model. |
| A3 | Framework postulate | The two-sided reading is the main numerical assumption. Every result depending on the factor of two remains conditional on A3. |
| A4 | Open physical postulate | Saturation requires a defined capacity, state space, and dynamics. Its threshold is explicitly open. |
| A5 | Conservation postulate | Must be instantiated as a conserved measure or current before physical use. |
| A6 | Definition of admissible reduction | Mathematically meaningful for a specified operator algebra. It does not itself prove that a physical reduction has this form or that a unique averaging group exists. |

## Definitions D1--D18

D1--D18 remain definitions of the framework's vocabulary. D11's binary definition of a record is intentionally strong and does not describe every graded/noisy physical record. D13's self-duality does not by itself imply an even unimodular lattice. D18 introduces, rather than derives, the three orthogonal projector roles.

## Results T1--T39

| ID | Living-edition grade | Scientific ruling |
|---|---|---|
| T1 | Internal lemma | A unique order follows only if the seven dependencies really form the asserted chain. State the relation explicitly and prove uniqueness as a finite-order lemma. |
| T2 | Internal uniqueness lemma | Retain after the admissible class of update matrices is written explicitly. |
| T3 | Exact algebraic result | The positive fixed point of the stated recurrence is \(\varphi\). Physical relevance is separate. |
| T4 | Exact conditional algebra | The value \(r=(2\varphi)^{-1}\) follows from the particular two-sided normalisation A3; it is not independently derived. |
| T5 | Exact algebraic identity | \((u+r)^2=u^2+2ur+r^2=1\). Sector names are interpretations. |
| T6 | Conjectural quantisation rule | Binary record status does not by itself entail an energetic or probabilistic price exactly equal to \(r\). Preserve as a postulated bridge to be tested. |
| T7 | Exact conditional identity | Once \(r\) and a three-crossing history are assumed, \(r^3=(\sqrt5-2)/8\). |
| T8 | Conditional selection theorem | Rank-eight positive-definite even unimodular lattices are uniquely \(E_8\), but self-duality, integrality, evenness, positive definiteness, and minimal rank must each be supplied. No physical carrier is established by classification alone. |
| T9 | Incomplete internal argument | ``Read twice'' does not imply even integral norm until the bilinear pairing and integral lattice are formally defined. Retain as a target lemma, not a proved theorem. |
| T10 | Mathematical lemma plus physical bridge | Three suitable \(E_8\) roots can close a triangle; interpreting this as the unique minimal physical history is conditional on the admissible-move rules. |
| T11 | Exact geometry with notation correction | For roots of squared norm two and inner product \(-1\), the parallelogram area is \(\sqrt3\) and the triangle area is \(\sqrt3/2\). The edition must state which cell is meant. |
| T12 | Reproducible numerical/combinatorial result | Retain with exact projection convention, code hash, tolerance, and preferably a symbolic proof of the golden pairing. |
| T13 | Internal operator-algebra result | If \(C\) is the specified idempotent reduction, \(\ker(I-C)=\operatorname{ran}C\). Calling this image the physical algebra is a definition/identification. |
| T14 | Exact operator observation | An idempotent minimal generator has a restricted spectrum; a general positive generator with the same kernel need not. This does not derive a mass spectrum. |
| T15 | Framework postulate/argument | One retained temporal order is not derived merely from calling the object one record. Treat rank-one time as an explicit structural assumption. |
| T16 | Framework postulate/argument | ``One enacted closure'' does not prove a one-dimensional closure mode without a representation theorem. |
| T17 | Conditional metric construction | A \(3+1\) split with opposite signs gives Lorentzian signature. The split and sign assignment are assumptions unless independently derived. |
| T18 | Established external theorem, carefully delimited | Alexandrov--Zeeman-type results recover Lorentz/conformal structure under dimension, bijectivity, and causality-preservation hypotheses. They do not supply absolute scale or prove the corpus's projector construction. |
| T19 | Withdrawn as a proof; retained as an operational postulate | Absence of a distinguishing event does not logically force coherent quantum superposition; a classical probability mixture also avoids selecting an actual alternative in the description. A reconstruction needs composition, interference, tomography, and continuity axioms. |
| T20 | Conditional representation result | Continuous unit-modulus characters of additive action have exponential form. Complex Hilbert structure is not forced until the domain, composition law, reversibility, and nontrivial phase scale are specified. |
| T21 | Established external theorem under named hypotheses | Gleason/Busch/Caves-type results yield trace-form probabilities from noncontextual additivity assumptions. They do not follow from ``even-handedness'' alone. |
| T22 | Established external theorems under named hypotheses | Wigner and Stone apply to transition-probability-preserving bijections and strongly continuous one-parameter unitary groups, respectively. Energy is a physical identification of the generator. |
| T23 | Exact algebra; conditional physics | The cross term equals \(2ur\). Calling it the universal physical boundary/interference weight requires a model-specific amplitude map. |
| T24 | Algebraic construction; conjectural gravity | Expanding a squared defect gives three coefficient classes. Equality with a gravitational action requires fields, form degree, invariant pairing, dimensions, gauge group, and variational equations. |
| T25 | Classification proposal | The commuting/noncommuting split is a useful taxonomy. It does not by itself produce gauge bosons, matter fields, or masses. |
| T26 | Persistence criterion | Retain as a definition/postulate for longitudinal identity, not a general theorem forbidding all replacement dynamics. |
| T27 | Internal consequence of D11 plus interpretation | A coherent superposition is not a definite record in the chosen sense. Claims about intrinsic unreadability of outcome selection remain interpretive. |
| T28 | Physical conjecture, not a GR theorem | General relativity admits recollapsing solutions. The corpus may prohibit them only after A5/T26 are realised as covariant dynamics and shown compatible with observation. |
| T29 | Conditional rank bookkeeping | If the geometry block is five-dimensional and the time and closure subspaces are rank one, the remaining rank is three. The premise is not independently derived. |
| T30 | Finite Lie-theoretic/computational result | Retain with an exact classification reference or exhaustive certificate. Clarify whether ``subsystem'' means closed root subsystem up to the Weyl group. |
| T31 | Multi-stage conjectural selection | The complement calculations can be exact, but irreducibility does not alone force one decay operator, and the family interpretation is not established by a \(1+3\) index split. |
| T32 | Reproducible finite construction | Antipodal root pairs guarantee zero total sum. The additional admissibility/adjacency conditions on the 240-step ordering must be stated and certified. |
| T33 | Conjectural action identification | The coefficient pattern resembles a MacDowell--Mansouri expansion, but ``term for term'' is premature until the connection, curvature, symmetry breaking, invariant trace, dimensions, and boundary terms are explicit. |
| T34 | Open; inherited proof rejected | ``One closure'' does not imply that every loop contracts, and ``one world'' does not imply simple connectivity. Perelman's theorem applies only after a closed simply connected 3-manifold has been established. |
| T35 | Established hydrogen mathematics plus circular bridge | Fock derives the momentum-space \(S^3\) from the Coulomb problem. Finite design sampling of those harmonics is valid; deriving Coulomb hydrogen from the same imported \(S^3\) is circular. The independent \(S^3\), \(1/r\), and coupling derivations remain open. |
| T36 | Conjectural chirality mechanism | A finite decay group does not by itself establish that the Distler--Garibaldi hypotheses are avoided in a complete Lorentz-covariant field theory. The traversal-to-Dirac-mass bridge and the chiral spectrum remain open. |
| T37 | Conditional operator-algebra result plus finite search | Tomiyama's theorem and finite-group averaging apply under precise algebraic hypotheses. Uniqueness requires the fixed algebra and covariance action to be specified. A sampled search over rootless subspaces is not an exhaustive proof unless completeness is certified. |
| T38 | Reproduction of standard GUT branching | The exterior-algebra charge table and \(3/8\) unification value are established \(SU(5)/SO(10)\) representation theory. What remains new and unproved is the physical derivation of the \(3+2\) split from traversal reversibility. |
| T39 | Exact internal numerical identity; speculative physical identification | The displayed power of \(r\) can be checked algebraically. Equating it with the observed Planck/cosmological hierarchy requires a dimensionally complete, non-circular map to measured constants and uncertainty propagation. |

## Consequences for the rewritten series

1. No chapter will use a single undifferentiated ``PROVED'' category.
2. Exact computations will be separated from physical identifications in adjacent, visibly labelled statements.
3. T19, T34, and the strongest forms of T33, T35, T36, and T39 will not be presented as established derivations.
4. Negative results---SPARC non-identifiability, equal family projections, missing coupling, and incomplete dynamics---will appear in the main narrative, not an appendix of caveats.
5. Superseded claims remain traceable in the source crosswalk, but the living edition has no immutable or frozen scientific state.
