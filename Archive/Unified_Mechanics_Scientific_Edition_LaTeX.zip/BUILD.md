# Unified Mechanics — Complete Scientific Edition source

Edition date: 3 August 2026

## Requirements

- Tectonic 0.16.9 or later
- Poppler `pdfinfo` and `pdftoppm` for verification
- Python 3 with `pypdf` for structural checks

## Five volumes, omnibus, and current position

From this directory:

```text
tectonic current-scientific-position.tex
tectonic volume-i.tex
tectonic volume-ii.tex
tectonic volume-iii.tex
tectonic volume-iv.tex
tectonic volume-v.tex
tectonic unified-mechanics-series.tex
```

These documents share `umseries.sty`, `references.bib`, and `volumes/`.

## Canonical Derivation Programme

```text
cd derivation-programme
tectonic main.tex
```

The canonical public filename is `Unified_Mechanics_Derivation_Programme.pdf`.

## Nine-Step Closure

The complete released source is under `nine-step-closure/`. From its `latex/` directory:

```text
tectonic main.tex
```

The adjacent `certificates/`, `evidence/`, and `scripts/` directories contain the reproducibility layer used by the closure volume.

## Audit materials

The 491-source historical coverage ledger is supplied under `audit/`. Its mapping and review-status fields describe the archival source-mapping exercise; scientific grades are governed by Volume V and the Nine-Step register.

The full source crosswalk can be regenerated from the ledger with `generate_source_crosswalk.py`, but the printed Volume V deliberately retains only a concise disposition summary. This keeps the scientific register readable while preserving the complete machine audit.

## Release verification

For every final PDF:

1. require a zero Tectonic exit code;
2. check the retained log for TeX errors, unresolved references, and overfull boxes;
3. reopen the PDF and verify page count and extractable text;
4. render every page with `pdftoppm`;
5. inspect page images for clipping, overlaps, missing glyphs, broken equations, and inconsistent page furniture;
6. generate the package inventory and SHA-256 manifest only after the final files are frozen.

The release-level results are recorded in `Unified_Mechanics_Verification_Report.md`.
