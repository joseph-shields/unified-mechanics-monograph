from pathlib import Path
from PIL import Image, ImageDraw

qa = Path(__file__).resolve().parents[1] / "qa"
pages = sorted(qa.glob("page-*.png"))
per_sheet = 10
thumb_w, thumb_h = 252, 360
margin, label_h = 18, 24

for batch_no, start in enumerate(range(0, len(pages), per_sheet), 1):
    batch = pages[start : start + per_sheet]
    sheet = Image.new("RGB", (margin * 3 + thumb_w * 2,
                              margin * 6 + (thumb_h + label_h) * 5), "#d8d5cf")
    draw = ImageDraw.Draw(sheet)
    for slot, path in enumerate(batch):
        row, col = divmod(slot, 2)
        x = margin + col * (thumb_w + margin)
        y = margin + row * (thumb_h + label_h + margin)
        with Image.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
            px = x + (thumb_w - im.width) // 2
            py = y + label_h + (thumb_h - im.height) // 2
            sheet.paste(im, (px, py))
        page_no = int(path.stem.split("-")[-1])
        draw.text((x, y), f"Page {page_no}", fill="#111111")
    sheet.save(qa / f"contact-{batch_no:02d}.png", optimize=True)

print(f"Rendered {len(pages)} pages into {batch_no} contact sheets.")
