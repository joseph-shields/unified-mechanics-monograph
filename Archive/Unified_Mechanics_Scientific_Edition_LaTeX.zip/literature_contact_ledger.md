# Literature-contact and claim-grade ledger

This ledger governs how the living scientific edition relates the corpus to established mathematics, established physics, empirical evidence, and open research. A citation establishes provenance or contact; it never upgrades an internal assumption into an external result.

## Governing distinction

Every central statement must be labelled as one of the following.

- **Established external result:** reproduced or invoked with its hypotheses and a primary or authoritative citation.
- **Internal theorem:** follows from definitions and assumptions stated in this edition; its conclusion is only as physical as those assumptions.
- **Conditional identification:** equates an internal object with a physical object under an explicit bridge assumption.
- **Phenomenological comparison:** compares a parameter-free or fitted construction with data and reports the statistical protocol.
- **Conjecture or programme:** a precise, attackable proposal for which no derivation or decisive test yet exists.
- **Exposure:** a conflict, degeneracy, missing coupling, circularity, or non-identifiability that constrains the framework.
- **Withdrawn claim:** retained in provenance but not asserted in the scientific edition.

## Foundations and self-reference

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Distinction as a primitive operation | Spencer-Brown (1969) | Historical and conceptual comparison only. The corpus separates act, boundary, state, crossing, and record; it must not claim that this separation follows from *Laws of Form*. |
| Self-description and fixed points | Lawvere (1969) | Use as mathematical context for diagonal/fixed-point phenomena. The specific map leading to the golden-ratio fixed point is an internal modelling choice, not a corollary of Lawvere's theorem. |
| The equation \(x=1+1/x\) and \(\varphi\) | Elementary algebra | Internal identity. No physical significance follows without a separately stated physical bridge. |
| Three-term partition of a square | Elementary algebra | Exact identity after the retained fraction is defined. Interpreting the terms as physical sectors is conditional. |

## Information, records, and recovery

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Records and channel loss | Shannon (1948); Cover and Thomas (2006) | Use standard channel, kernel, sufficient-statistic, and data-processing terminology. Do not say that a decoder recovers distinctions erased by a channel. |
| Recovery under a structural prior | Donoho (2006); Cand\`es--Romberg--Tao (2006) | Analogy or conditional formalisation unless restricted-isometry/sparsity hypotheses are proved for the actual measurement map. A prior restricts an ensemble; it does not add sample-specific data. |
| Irreversibility of record erasure | Landauer (1961); Bennett (1982) | Thermodynamic contact only. Logical irreversibility and physical dissipation require explicit computational and reservoir assumptions. |
| ``Overwrite is forbidden'' | No direct external theorem | Internal persistence postulate or conditional criterion, never a universal law of physics without a physical model. |

## Variational structure and action

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Symmetry and conserved quantities | Noether (1918) | Established theorem under differentiability and variational-symmetry hypotheses. |
| Reconstructing a Lagrangian from equations | Anderson (1992); modern inverse-variational literature | The Helmholtz conditions are a real gate. An arbitrary evolution equation need not be Euler--Lagrange without a multiplier, auxiliary fields, or enlarged state space. |
| Actions differing by boundary/null terms | Gibbons--Hawking (1977); York (1972); variational bicomplex | Bulk Euler--Lagrange equivalence can be too coarse for boundary charges and a well-posed variational principle. This supports the corpus's transcription warning, not its entire ontology. |
| Informational least action | Isoperimetric geometry plus internal definitions | The geometric minimiser is an internal theorem only after the informational boundary density and admissible class are postulated. The physical identification is conditional. |
| Single-cell boundary minimisation | Osserman (1978) and the classical isoperimetric inequality | A ball minimises boundary area for fixed enclosed volume in Euclidean space. This does not determine a many-cell tessellation or a physical vacuum. |
| Planar equal-area partition | Hales (2001) | The regular hexagonal honeycomb is the proved planar minimiser under the theorem's hypotheses. Do not transfer this result to three-dimensional foam without a new theorem. |
| Equal-volume three-dimensional foam | Weaire--Phelan (1994) | The Weaire--Phelan structure is a counterexample to Kelvin's candidate and a best-known competitor, not a proved global optimum. |

## Quantum structure

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Born probabilities | Born (1926); Gleason (1957); Busch (2003); Caves et al. (2004) | State the hypotheses exactly. Gleason gives the trace form for noncontextual measures on projections in dimension at least three; generalized-effect results cover two-dimensional cases under stronger measurement assumptions. This is not a derivation from ``fairness'' alone. |
| Symmetry transformations | Wigner (1959) | Transition-probability-preserving ray bijections are implemented by unitary or antiunitary maps. Continuity of a one-parameter evolution selects the unitary connected component only after group and continuity assumptions are supplied. |
| Hamiltonian generator | Stone (1932) | A strongly continuous one-parameter unitary group has a unique self-adjoint generator. Calling that generator physical energy is an additional physical identification. |
| Path amplitudes | Feynman (1948) | Established formulation/contact. The corpus's ``unresolved alternatives'' language is interpretive unless a reconstruction theorem supplies the complex Hilbert structure and composition law. |
| Measurement and persistent records | Ozawa (1984); Zurek (2003) | Separate unitary premeasurement, decoherence, outcome conditioning, and semantic report. Decoherence does not by itself select a unique experienced outcome. |
| Holonomy and phase | Berry (1984); Aharonov--Anandan (1987) | Established geometric phase results. A new co-distinction field requires an independent definition and empirical coupling; resemblance to holonomy is not evidence. |

## Causality, traversal, and relativity

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Causal order constraining geometry | Zeeman (1964); Malament (1977) | Quote dimensional, bijectivity, chronology/distinguishing, and regularity assumptions. Causal structure determines conformal structure under specific hypotheses, not an arbitrary metric with its absolute scale. |
| G\"odel spacetime | G\"odel (1949) | Established counterexample with closed timelike curves and failure of ordinary causal hierarchy conditions. A lifted traversal index is a proposed augmentation, not a consequence of general relativity. |
| Helical lift of recurrent paths | Standard covering-space idea plus internal state coordinate | Mathematically legitimate construction. Physical necessity, uniqueness, and measurability of the lift remain conjectural unless a covariant dynamics and observable are provided. |
| AdS/CFT radial evolution | Maldacena (1998); Witten (1998) | Use only as contact with holographic scale/radial evolution. A sign change or lifted history coordinate is not automatically a new holographic duality. |

## Carrier geometry and exceptional structures

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| \(E_8\) as the rank-eight even unimodular lattice/root system | Conway and Sloane (1999); standard Lie theory | Established mathematics: 240 roots, rank eight, evenness and unimodularity. Selecting \(E_8\) from physical admissibility still depends on the completeness and independence of the corpus's selection axioms. |
| \(E_8\)-to-\(H_4\) golden decomposition/projection | Elser--Sloane (1987); Koca--Koca--Ko\c{c} (1998) | Established mathematical contact. The existence of a golden projection does not establish a physical carrier. |
| 24-cell and 600-cell design strength | Delsarte--Goethals--Seidel (1977), standard design computations | Cite the general theory and include the corpus's exact coordinate certificate. The finite harmonic sampling cutoffs follow from design strength. |
| Direct \(E_8\) particle unification | Distler--Garibaldi (2010) | Their no-go theorem must be stated accurately. Any claimed evasion must demonstrate which hypothesis is absent and still provide a Lorentz-covariant chiral quantum field theory. A finite Weyl action alone does not supply the missing field theory. |

## Gauge, matter, and gravity

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Non-Abelian gauge curvature | Yang--Mills (1954) | Established physical/mathematical structure. Identifying an internal nonclosure operator with a gauge connection requires local symmetry, bundle, and coupling data. |
| One family in the spinor \(\mathbf{16}\) of \(SO(10)\) | Fritzsch--Minkowski (1975) | Established grand-unified representation theory, including a right-handed neutrino. The corpus may reproduce this branching but cannot claim it discovered the charge pattern. |
| \(SU(5)\) hypercharge and \(\sin^2\theta_W=3/8\) at unification | Georgi--Glashow (1974) and standard GUT normalisation | Established consequence of canonical unified normalisation, not an observed low-energy value. Running and threshold corrections are required before comparison with experiment. |
| MacDowell--Mansouri action | MacDowell--Mansouri (1977) | Established gauge-gravity formulation with symmetry reduction. The claim that the corpus's averaging projection supplies this reduction is conditional until the fields, groups, and action map are written explicitly. |
| First-order field equations and torsion | Hehl et al. (1976) | Standard variation result only for the stated action and matter coupling. Spinful matter can source torsion; ``torsion vanishes'' is not universal. |
| Strong \(CP\) problem | Peccei--Quinn (1977); Weinberg (1978); Wilczek (1978); Abel et al. (2020) | The small bound on \(\bar\theta\) is empirical. The corpus's reversibility argument is a conjectural compatibility statement until it yields the QCD topological term and demonstrates why its coefficient or sectors vanish without contradicting anomaly and vacuum structure. |
| Family number and masses | Internal enumeration plus established representation theory | A count of three orbits is not a derivation of three physical generations without a field-theoretic identification. Equal projected values imply an exposed mass degeneracy; the Yukawa operator and mixing matrices remain missing. |

## Hydrogen and finite sampling

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Momentum-space \(S^3\) and hidden \(SO(4)\) symmetry of Coulomb hydrogen | Fock (1935) | Established. Because Fock's \(S^3\) is obtained from the Coulomb problem, using it to recover the Coulomb potential without an independent route to \(S^3\) is circular. |
| Exact finite sampling through \(n=3\) and \(n=6\) | Delsarte et al. (1977) plus coordinate certificates | A 5-design integrates products of harmonics through degree 2, and an 11-design through degree 5; with Fock's degree \(N=n-1\), this explains the cutoffs. It is exact cubature, not a derivation of atomic dynamics. |
| Coulomb scale and Rydberg | Standard quantum mechanics | Remains open unless the framework derives both the \(1/r\) operator and its coupling without importing hydrogen data. |
| ``Three modes plus closure imply \(S^3\)'' | Poincar\'e/Perelman context | This does not follow from compactness or ``every traversal returns'' as written. A closed simply connected 3-manifold is homeomorphic to \(S^3\), but the framework must prove that its momentum-space object is a closed simply connected 3-manifold and must supply the relevant metric/differential structure. Until then the bridge is open. |

## Cosmology and empirical programmes

| Corpus contact | External literature | Scientific treatment in the new edition |
|---|---|---|
| Baseline cosmological parameters | Planck Collaboration (2020) | Report model dependence and covariance; do not present posterior means as raw observables. |
| Late-time expansion and evolving dark energy | DESI Collaboration (2025) and the exact supernova/CMB combinations used | Current empirical comparison; state data release, likelihood, combination, and model assumptions. No ``prediction'' may be claimed from a quantity chosen after inspecting these data. |
| Local distance ladder | Riess et al. (2022) | Use as one measurement programme in the Hubble-tension ledger, with systematics and model dependence stated. |
| IllustrisTNG comparison | Nelson et al. (2019); Springel et al. (2018) | Retrospective literature compatibility is not a prospective test. Catalogue-level tests require a locked adapter and withheld evaluation data. |
| SPARC pilot | Lelli et al. (2016); McGaugh et al. (2016) | Preserve the corpus's non-identifiability result. If the tested quadratic and baseline span the same feature space under the declared readout, the fit cannot distinguish them. |
| Equivalence principle | MICROSCOPE Collaboration (2022) | A quantitative null constraint. Any new long-range field must specify composition dependence and coupling before this bound can be applied. |

## Mandatory wording corrections

1. Replace unqualified **proved** with **proved within the stated formal system** whenever a conclusion depends on corpus postulates or physical identifications.
2. Replace **prediction** with **postdiction**, **retrospective compatibility**, or **forecast** according to whether the value and mapping were fixed before data access.
3. Replace **explains** with **encodes**, **reproduces**, or **would explain if the bridge is established** when a physical mechanism is missing.
4. Never infer physical uniqueness from algebraic elegance alone.
5. Treat every past edition marker as provenance. The series is corrigible and maintains a public supersession ledger; it has no frozen scientific state.
