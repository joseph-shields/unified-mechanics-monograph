# Unified Mechanics Formal Register — companion addendum NS1–NS9

Date: 2 August 2026

Authority: companion addendum only. It does not renumber, replace, or silently alter the governing Formal Register. Its purpose is to record the disposition of the historical nine-step queue against the current corpus and the new certificates produced for the closure volume.

## NS1 — Typed distinction and record calculus

**Status: PROVED for the stated formalization.**

Let \(\Sigma\) be an event alphabet, \(\Sigma^*\) its finite histories, and \(E:\Sigma\to R\) an event encoder into an append-only record alphabet. A history \(h=e_1\cdots e_n\) has record \(\mathcal R(h)=E(e_1)\cdots E(e_n)\). If \(E\) is injective, \(\mathcal R\) is injective. Prefix order is preserved by every bijective renaming of \(\Sigma\). Consequently, statements expressed only through equality, concatenation, prefix, composition, and quotient factorization do not depend on the vocabulary assigned to events.

Dependency: logic corpus T1–T6, TP, ML; companion proof and `step1_record_axioms_certificate.json`.

## NS2 — Lattice and subgroup certificate consolidation

**Status: PROVED or CONDITIONAL exactly as in T31–T38.**

The rank-eight carrier, rank-three subsystem classification, survivor, representation, family count, chirality bridge, charge table, and anomaly sums are carried forward with their named hypotheses. A fresh isolated rebuild completed 22/22 steps. No result is demoted by the historical editorial queue.

Dependency: T31–T38, O1–O4, Papers 21–26, `run_manifest.json`.

## NS3 — Local action and Euler–Lagrange system

**Status: PROVED for the gravitational variation and minimal metric source map; CONDITIONAL for the full carrier realization.**

The square \(D=uR+r\,e\wedge e\) reproduces the MacDowell–Mansouri coefficient ratios and \(\Lambda=3r/u=3/\sqrt5\). Variation with respect to coframe and connection gives the Einstein–Cartan equations; the bosonic spin-free sector has vanishing torsion and reduces to the Einstein equations with cosmological term. Minimal coupling of the Helical Relativity scalar metric yields the source projections \(\delta S_m/\delta\alpha_M=\sqrt{-g}\rho\), \(\delta S_m/\delta\alpha_L=3\sqrt{-g}p\), and \(\delta S_m/\delta\nu=\sqrt{-g}p\), up to the declared sign convention for \(T^0{}_0\).

Dependency: T24–T25, Papers 24–25, Helical Relativity metric map, `lagrangian_certificate.json`.

## NS4 — Chiral matter, anomalies, running, and the mass selector

**Status: mixed, with each component stated separately.**

- The 16-state chiral matter representation and Standard-Model charges are PROVED given T31 and the named chirality bridge.
- The gauge and mixed anomaly sums vanish exactly.
- The one-loop running coefficients are \((b_1,b_2,b_3)=(41/10,-19/6,-7)\) for three certified generations and one complex Higgs doublet.
- The mass-squared operator is located in the boundary \(15\) as \(\operatorname{ad}(X)^2\). The family–time restriction fixes one norm scale; the twelve remaining components carry splitting. Their stationary selector is the remaining numerical-hierarchy obligation.

Dependency: T36, T38, Papers 22, 25, 26; Helical Relativity Paper 29; `matter_action_certificate.json`, `forcing_certificate.json`, `step4_running_certificate.json`, `mass_operator_results.json`.

## NS5 — Dark-sector effective stress–energy and perturbations

**Status: DERIVED at the effective covariant level; microphysical carrier realization remains named.**

Spatial isotropy and conservation restrict each background component to perfect-fluid form. The cell-renewal law that holds \(\rho_\Lambda\) constant under expansion gives \(p_\Lambda=-\rho_\Lambda\). The neutral retained boundary component with conserved comoving number gives \(p_c=0\) and \(\rho_c\propto a^{-3}\). Linear scalar perturbations therefore enter the standard Einstein–Boltzmann system with the UM-fixed background fractions and adiabatic initial data. This statement fixes the effective stress–energy and transfer problem; it does not substitute for a discrete microscopic identity of the dark carrier.

Dependency: A02, A03, Helical Relativity, standard covariant conservation.

## NS6 — Full recombination and Einstein–Boltzmann evolution

**Status: COMPUTED.**

CAMB 2.0.1 was run to \(\ell_{\max}=3000\) with the frozen UM parameter dictionary. For the boundary reading it gives \(H_0=67.7532\ \mathrm{km\,s^{-1}\,Mpc^{-1}}\) from the declared acoustic anchor, \(z_*=1089.746\), \(r_*=143.971\ \mathrm{Mpc}\), and TT peak locations \(\ell=(220,536,813,1126)\). The RMS fractional TT difference from the matched Planck-control theory curve over \(30\le\ell\le2500\) is 0.01665. This is a transfer-code comparison, not a Planck likelihood evaluation.

Dependency: `step6_camb_certificate.json` and its four spectra tables.

## NS7 — Prospective observable maps

**Status: FROZEN for closure count, Hubble basins, and vacuum response; scale frozen but response kernel outstanding for short-range gravity.**

The primary closure estimator is \(\hat n=-\ln(H_c/H_l)/\ln(1-r^3)\). The vacuum maps are \(\lambda=(4\pi/\sqrt3)r^{240}\) and \(G=8\pi c^3 r^{241}(1-r^3)^2/(\hbar\Lambda)\). The matter-channel cell scale is \(48.9819\,\mu\mathrm m\). A short-range apparatus comparison requires a derived granularity kernel and may not silently substitute a Yukawa potential.

Dependency: `step7_8_observable_protocols.json`.

## NS8 — Preregistration and withheld tests

**Status: PROTOCOLS FROZEN; computational transfer test executed; new measurements remain prospective.**

The Hubble, vacuum, short-range gravity, and running-retention protocols name raw inputs, primary statistics, blinding or designation rules, and outcome-neutral revision requirements. New experimental data have not been manufactured or retrospectively labelled as withheld.

Dependency: companion preregistration chapter and `step7_8_observable_protocols.json`.

## NS9 — Outcome-neutral revision

**Status: PROVED as a governance rule and enacted by this addendum.**

Every execution appends its inputs, version, hash, statistic, uncertainty, and interpretation to the register. A result may strengthen, refine, redirect, or leave unchanged a physical interpretation; it does not erase the calculation that produced it. Negative language is reserved for an explicit contradiction under the declared premises, not for a question whose interpretation or constitutive bridge is still being derived.
