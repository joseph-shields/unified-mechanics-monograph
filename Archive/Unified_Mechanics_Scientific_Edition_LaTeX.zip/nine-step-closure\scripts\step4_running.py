"""One-loop gauge-running certificate for the certified UM matter spectrum.

The beta coefficients are derived from the 16-state SO(10) generation after
restriction to SU(3)xSU(2)xU(1), with three generations and one complex Higgs
doublet. Numerical electroweak inputs are an explicitly imported comparison,
not parameters derived by this script.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "certificates"
OUT.mkdir(parents=True, exist_ok=True)

# General one-loop convention:
# d alpha_i^{-1}/d ln(mu) = -b_i/(2*pi).
b1 = Fraction(41, 10)
b2 = Fraction(-19, 6)
b3 = Fraction(-7, 1)

# Imported M_Z comparison values (PDG/Planck-era convention).
MZ = 91.1876
alpha_em_inv = 127.955
sin2w = 0.23122
alpha_s = 0.1179
alpha_em = 1.0 / alpha_em_inv
alpha1 = Fraction(5, 3) * alpha_em / (1.0 - sin2w)
alpha2 = alpha_em / sin2w
alpha3 = alpha_s
ainv = [1.0 / float(alpha1), 1.0 / alpha2, 1.0 / alpha3]
b = [float(b1), float(b2), float(b3)]


def run_inverse(a0, beta, log_ratio):
    return a0 - beta * log_ratio / (2.0 * math.pi)


log12 = 2.0 * math.pi * (ainv[0] - ainv[1]) / (b[0] - b[1])
mu12 = MZ * math.exp(log12)
at12 = [run_inverse(ainv[i], b[i], log12) for i in range(3)]

phi = (1.0 + math.sqrt(5.0)) / 2.0
r = 1.0 / (2.0 * phi)
alpha_s_legacy = r * r * (1.0 + r - r * r)

script = Path(__file__).resolve()
cert = {
    "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
    "status": "completed",
    "convention": "d(alpha_i^-1)/d ln(mu) = -b_i/(2 pi), g1 is SU(5)-normalised",
    "spectrum": "three certified 16-state generations plus one complex Higgs doublet",
    "derivation": {
        "SU3": {"gauge": "-11", "three_generations": "+4", "scalar": "0", "b3": str(b3)},
        "SU2": {"gauge": "-22/3", "three_generations": "+4", "Higgs": "+1/6", "b2": str(b2)},
        "U1": {"three_generations": "+4", "Higgs": "+1/10", "b1": str(b1), "normalisation": "kY=5/3"},
    },
    "beta_coefficients": {"b1": str(b1), "b2": str(b2), "b3": str(b3)},
    "imported_MZ_benchmark": {
        "MZ_GeV": MZ,
        "alpha_em_inverse": alpha_em_inv,
        "sin2_thetaW_MSbar": sin2w,
        "alpha_s": alpha_s,
        "alpha_inverse_GUT_normalised": {"a1": ainv[0], "a2": ainv[1], "a3": ainv[2]},
    },
    "minimal_single_threshold_running": {
        "mu_alpha1_equals_alpha2_GeV": mu12,
        "log_mu_over_MZ": log12,
        "inverse_couplings_at_crossing": {"a1": at12[0], "a2": at12[1], "a3": at12[2]},
        "a3_inverse_offset_from_a12": at12[2] - at12[0],
        "interpretation": "The RG map is fixed by the certified spectrum. A numerical three-coupling boundary statement additionally requires the UM threshold and overall normalisation; neither is silently fitted here.",
    },
    "legacy_candidate_not_used_as_boundary_condition": {
        "formula": "alpha_s(MZ)=r^2(1+r-r^2)",
        "value": alpha_s_legacy,
        "relative_to_imported_benchmark": alpha_s_legacy / alpha_s - 1.0,
    },
    "sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
}

path = OUT / "step4_running_certificate.json"
path.write_text(json.dumps(cert, indent=2), encoding="utf-8")
print(json.dumps({"certificate": str(path), "b": [str(b1), str(b2), str(b3)],
                  "mu12_GeV": mu12, "inverse_at_mu12": at12,
                  "legacy_alpha_s": alpha_s_legacy}, indent=2))
