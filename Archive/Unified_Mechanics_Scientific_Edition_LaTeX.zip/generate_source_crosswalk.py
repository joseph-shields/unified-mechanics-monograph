"""Generate the full LaTeX source-disposition crosswalk from the corpus ledger.

This is a mechanical renderer. The editorial assignments live in
full_corpus_index/coverage_ledger_mapped.csv and remain the auditable source.
"""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "full_corpus_index" / "coverage_ledger_mapped.csv"
OUTPUT = ROOT / "latex_series" / "generated" / "source_crosswalk.tex"

ROLE_CODES = {
    "manuscript": "MS",
    "historical_manuscript": "HIST",
    "implementation": "CODE",
    "data_or_certificate": "CERT",
    "supporting_text": "NOTE",
    "orientation_or_ledger": "LEDGER",
    "manifest": "MANIFEST",
}


def tex(value: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in (value or ""))


def path_tex(value: str) -> str:
    """Render a path faithfully while giving TeX plentiful break points."""
    repaired = (
        (value or "")
        .replace("â€”", "—")
        .replace("â€“", "–")
        .replace("â€™", "’")
        .replace("Â", "")
    )
    pieces: list[str] = []
    for ch in repaired:
        if ch == "/":
            pieces.append(r"/\allowbreak{}")
        elif ch == " ":
            pieces.append(r"\space\allowbreak{}")
        elif ch == "-":
            pieces.append(r"-\allowbreak{}")
        elif ch == "_":
            pieces.append(r"\_\allowbreak{}")
        else:
            pieces.append(tex(ch))
    return "".join(pieces)


def main() -> None:
    with INPUT.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))

    role_counts = Counter(row["role"] for row in rows)
    volume_counts = Counter(row["planned_volume"] for row in rows)

    out: list[str] = [
        "% Generated from coverage_ledger_mapped.csv; do not hand-edit.",
        r"\chapter{Complete source-disposition crosswalk}",
        "",
        (
            "This appendix enumerates every unique text-bearing source in the indexed "
            f"corpus: {len(rows)} records after exact-hash deduplication. The authoritative "
            "machine-readable ledger retains the absolute path, full SHA-256 digest, format, "
            "topic labels, claim labels, planned section, and audit status. The compact table "
            "below prints the fields required to trace every source into the series."
        ),
        "",
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{Crosswalk population by source role.}",
        r"\begin{tabular}{@{}lr@{}}",
        r"\toprule",
        r"Role & Unique sources \\",
        r"\midrule",
    ]
    for role, count in sorted(role_counts.items()):
        out.append(f"{tex(role.replace('_', ' '))} & {count} \\\\")
    out.extend(
        [
            r"\midrule",
            f"Total & {len(rows)} \\\\",
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
            (
                "Volume assignments may contain more than one Roman numeral where a source "
                "supports several stages of the argument. Role codes are MS, HIST, CODE, "
                "CERT, NOTE, LEDGER, and MANIFEST, corresponding to the full roles above. "
                "A source listed here is not thereby "
                "endorsed; its disposition states where it was preserved, consolidated, "
                "corrected, superseded, or used as a certificate."
            ),
            "",
            r"\begingroup",
            r"\small",
            r"\Urlmuskip=0mu plus 2mu\relax",
            r"\setlength{\LTpre}{0.5em}",
            r"\setlength{\LTpost}{0pt}",
            r"\begin{longtable}{@{}>{\RaggedRight\arraybackslash}p{0.07\textwidth}>{\RaggedRight\arraybackslash}p{0.12\textwidth}>{\RaggedRight\arraybackslash}p{0.15\textwidth}>{\RaggedRight\arraybackslash}p{0.56\textwidth}@{}}",
            r"\caption{Complete crosswalk of unique text-bearing corpus sources.}\label{tab:source-crosswalk}\\",
            r"\toprule",
            r"ID & Volume & Role & Source and disposition \\",
            r"\midrule",
            r"\endfirsthead",
            r"\multicolumn{4}{l}{\footnotesize\itshape Table \thetable\ continued from the preceding page}\\",
            r"\toprule",
            r"ID & Volume & Role & Source and disposition \\",
            r"\midrule",
            r"\endhead",
            r"\midrule",
            r"\multicolumn{4}{r}{\footnotesize\itshape Continued on the following page}\\",
            r"\endfoot",
            r"\bottomrule",
            r"\endlastfoot",
        ]
    )

    for index, row in enumerate(rows, start=1):
        source = path_tex(row["source_path"])
        section = tex(row["planned_section"])
        status = tex(row["coverage_status"].replace("_", " "))
        digest = row["sha256"][:12]
        out.extend(
            [
                (
                    f"\\texttt{{S{index:04d}}} & {tex(row['planned_volume'])} & "
                    f"{ROLE_CODES[row['role']]} & "
                    f"{{\\ttfamily {source}}} \\\\"
                ),
                (
                    r"\multicolumn{3}{@{}r}{\scriptsize\color{UMTeal}"
                    f"{digest}"
                    r"\hspace{0.5em}} & \scriptsize\textit{"
                    f"{section}; {status}"
                    r"} \\[0.35em]"
                ),
            ]
        )

    out.extend([r"\end{longtable}", r"\endgroup", ""])
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text("\n".join(out), encoding="utf-8")

    # A small check printed for the build log.
    print(f"wrote {OUTPUT} with {len(rows)} sources")
    print("volume assignments:", dict(sorted(volume_counts.items())))


if __name__ == "__main__":
    main()
