"""Render publication figures from the frozen step-6 CSV outputs."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "vendor"))
import matplotlib.pyplot as plt
import numpy as np

CERT = ROOT / "certificates"
FIG = ROOT / "latex" / "figures"
FIG.mkdir(parents=True, exist_ok=True)

ink = "#1a1a1a"
accent = "#1f3b57"
soft = "#77736c"
plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.edgecolor": soft,
    "axes.labelcolor": ink, "xtick.color": ink, "ytick.color": ink,
    "text.color": ink, "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 160, "savefig.bbox": "tight",
})

control = np.genfromtxt(CERT / "planck_control_spectra.csv", delimiter=",", names=True)
um = np.genfromtxt(CERT / "um_boundary_spectra.csv", delimiter=",", names=True)
n_common = min(len(control), len(um))
control = control[:n_common]
um = um[:n_common]

fig, (ax, ar) = plt.subplots(2, 1, figsize=(6.0, 5.0), sharex=True,
                             gridspec_kw={"height_ratios": [3.0, 1.0], "hspace": 0.08})
mask = (um["ell"] >= 2) & (um["ell"] <= 2500)
ax.plot(control["ell"][mask], control["TT_Dell_uK2"][mask], color=soft, lw=1.0,
        label="Planck-parameter control")
ax.plot(um["ell"][mask], um["TT_Dell_uK2"][mask], color=accent, lw=1.1,
        label="Unified Mechanics boundary reading")
ax.set_ylabel(r"$D_\ell^{TT}$ [$\mu$K$^2$]")
ax.legend(frameon=False, loc="upper right", fontsize=8)
ax.set_xlim(2, 2500)
ax.grid(color="#dedbd4", lw=0.35, alpha=0.55)

resid = (um["TT_Dell_uK2"][mask] - control["TT_Dell_uK2"][mask]) / control["TT_Dell_uK2"][mask]
ar.axhline(0, color=soft, lw=0.6)
ar.plot(um["ell"][mask], 100 * resid, color=accent, lw=0.9)
ar.set_ylabel("difference [%]")
ar.set_xlabel(r"multipole $\ell$")
ar.grid(color="#dedbd4", lw=0.35, alpha=0.55)
fig.savefig(FIG / "step6_tt_spectrum.pdf")
fig.savefig(FIG / "step6_tt_spectrum.png", dpi=220)
plt.close(fig)

hc = np.genfromtxt(CERT / "planck_control_recombination.csv", delimiter=",", names=True)
hu = np.genfromtxt(CERT / "um_boundary_recombination.csv", delimiter=",", names=True)
fig, ax = plt.subplots(figsize=(6.0, 3.7))
ax.plot(hc["z"], hc["x_e"], color=soft, lw=1.0, label=r"control $x_e$")
ax.plot(hu["z"], hu["x_e"], color=accent, lw=1.1, label=r"UM $x_e$")
ax.set_xlabel("redshift $z$")
ax.set_ylabel(r"free-electron fraction $x_e$")
ax.set_xlim(700, 1500)
ax.grid(color="#dedbd4", lw=0.35, alpha=0.55)
av = ax.twinx()
v = hu["visibility_Mpc_inv"]
av.plot(hu["z"], v / np.max(v), color="#9a958c", lw=0.9, ls="--",
        label="UM visibility (normalised)")
av.set_ylabel("normalised visibility", color=soft)
av.tick_params(axis="y", colors=soft)
lines, labels = ax.get_legend_handles_labels()
lines2, labels2 = av.get_legend_handles_labels()
ax.legend(lines + lines2, labels + labels2, frameon=False, loc="upper left", fontsize=8)
fig.savefig(FIG / "step6_recombination.pdf")
fig.savefig(FIG / "step6_recombination.png", dpi=220)
plt.close(fig)

print(FIG)
