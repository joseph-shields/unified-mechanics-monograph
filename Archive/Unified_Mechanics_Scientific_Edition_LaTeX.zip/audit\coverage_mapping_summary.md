# Provisional full-corpus mapping

Text-bearing unique sources mapped: 491

## Counts by planned volume assignment

- I: 21
- I; II: 2
- I; II; III; IV; V: 2
- I; III: 2
- II: 49
- II; IV; V: 2
- II; V: 4
- III: 50
- III; IV: 2
- III; V: 3
- IV: 35
- IV; V: 7
- V: 312

Manual-review fallback assignments: 0
